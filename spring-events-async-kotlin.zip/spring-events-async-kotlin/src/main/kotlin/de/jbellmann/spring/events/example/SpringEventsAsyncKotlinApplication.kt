package de.jbellmann.spring.events.example

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SpringEventsAsyncKotlinApplication

fun main(args: Array<String>) {
    runApplication<SpringEventsAsyncKotlinApplication>(*args)
}
